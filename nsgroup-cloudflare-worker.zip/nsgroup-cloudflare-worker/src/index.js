export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // Mantiene una única landing HTML y deja que los anchors internos funcionen.
    if (url.pathname === "/" || url.pathname === "/index.html") {
      const assetUrl = new URL("/index.html", request.url);
      const assetRequest = new Request(assetUrl, request);
      const response = await env.ASSETS.fetch(assetRequest);

      return new Response(response.body, {
        status: response.status,
        headers: {
          "content-type": "text/html; charset=UTF-8",
          "cache-control": "public, max-age=3600",
          "x-content-type-options": "nosniff",
          "referrer-policy": "strict-origin-when-cross-origin"
        }
      });
    }

    // Entrega otros recursos si se agregan luego a /public.
    return env.ASSETS.fetch(request);
  }
};
