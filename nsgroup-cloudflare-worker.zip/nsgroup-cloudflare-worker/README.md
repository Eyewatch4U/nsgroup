# NSGroup Credenciales 2026 — Cloudflare Worker

Proyecto listo para publicar en Cloudflare Workers usando Static Assets.

## Estructura

- `src/index.js`: Worker que sirve el HTML.
- `public/index.html`: landing corregida y auditada.
- `wrangler.toml`: configuración del Worker.

## Deploy sugerido

Desde la carpeta del proyecto:

```bash
npm install -g wrangler
wrangler login
wrangler deploy
```

## Nota operativa

El HTML pesa más de 5 MB por recursos embebidos. Por eso se entrega como Worker + Assets, no como un único archivo JS gigante. Es la opción más estable para Cloudflare.
